import QtQuick
import QtQuick.Controls as QtControls2
import QtQuick.Layouts
import QtQuick.Dialogs
import org.kde.kirigami as Kirigami
import org.kde.plasma.plasmoid
import "../code/wallhaven.js" as Wallhaven

ColumnLayout {
    id: root

    property var wallpaperConfiguration
    property alias formLayout: sourceForm

    readonly property var liveWallpaper: (typeof Plasmoid !== "undefined" && Plasmoid.wallpaperGraphicsObject)
        ? Plasmoid.wallpaperGraphicsObject
        : null

    readonly property string previewAttribution: {
        if (wallpaperConfiguration && wallpaperConfiguration.PreviewAttribution) {
            return wallpaperConfiguration.PreviewAttribution;
        }
        if (liveWallpaper && liveWallpaper.attributionText) {
            return liveWallpaper.attributionText;
        }
        return "";
    }

    readonly property string previewWallpaperId: {
        if (wallpaperConfiguration && wallpaperConfiguration.PreviewWallpaperId) {
            return wallpaperConfiguration.PreviewWallpaperId;
        }
        var match = /Wallhaven #([a-z0-9]+)/i.exec(previewAttribution);
        return match ? match[1] : "";
    }

    readonly property string previewThumbUrl: {
        if (previewWallpaperId) {
            return Wallhaven.thumbUrlForId(previewWallpaperId);
        }
        if (wallpaperConfiguration && wallpaperConfiguration.PreviewThumbUrl) {
            return wallpaperConfiguration.PreviewThumbUrl;
        }
        return "";
    }

    readonly property string previewFileUrl: {
        if (!wallpaperConfiguration) {
            return "";
        }
        var value = wallpaperConfiguration.PreviewImage;
        if (!value || value === "null") {
            return "";
        }
        return value;
    }

    readonly property string previewWallpaperDetails: {
        if (liveWallpaper && liveWallpaper.wallpaperDetailsText) {
            return liveWallpaper.wallpaperDetailsText;
        }
        if (wallpaperConfiguration && wallpaperConfiguration.PreviewWallpaperDetails) {
            return wallpaperConfiguration.PreviewWallpaperDetails;
        }
        return "";
    }

    readonly property real previewWidth: Math.min(420, Math.max(280, width > 0 ? Math.round(width * 0.55) : 360))
    readonly property real previewHeight: Math.round(previewWidth * 9 / 16)

    property alias cfg_SearchText: searchTextField.text
    property alias cfg_ApiKey: apiKeyField.text
    property alias cfg_BrowseMode: browseModeCombo.currentValue
    property alias cfg_CollectionUser: collectionUserField.text
    property alias cfg_CollectionId: collectionIdField.text
    property alias cfg_RandomInterval: intervalSpin.value
    property alias cfg_SlideshowPaused: slideshowPausedCheck.checked
    property alias cfg_IntervalJitterPercent: jitterSpin.value
    property alias cfg_DayIntervalMin: dayIntervalSpin.value
    property alias cfg_NightIntervalMin: nightIntervalSpin.value
    property alias cfg_CrossfadeMs: crossfadeSpin.value
    property alias cfg_TransitionMode: transitionCombo.currentValue
    property alias cfg_ImageQuality: qualityCombo.currentValue
    property alias cfg_FileTypeFilter: fileTypeCombo.currentValue
    property alias cfg_Sortings: sortingsCombo.currentValue
    property alias cfg_LocalSortings: localSortingsCombo.currentValue
    property alias cfg_Order: orderCombo.currentValue
    property alias cfg_CategoryGeneral: generalCheck.checked
    property alias cfg_CategoryAnime: animeCheck.checked
    property alias cfg_CategoryPeople: peopleCheck.checked
    property alias cfg_PuritySfw: sfwCheck.checked
    property alias cfg_PuritySketchy: sketchyCheck.checked
    property alias cfg_PurityNsfw: nsfwCheck.checked
    property alias cfg_MinWidth: minWidthField.text
    property alias cfg_MinHeight: minHeightField.text
    property alias cfg_Ratio: ratioCombo.currentValue
    property alias cfg_ColorFilter: colorCombo.currentValue
    property alias cfg_TopRange: topRangeCombo.currentValue
    property alias cfg_ExactResolutions: resolutionsField.text
    property alias cfg_UseBlacklist: blacklistCheck.checked
    property alias cfg_DedupEnabled: dedupCheck.checked
    property alias cfg_KenBurnsEnabled: kenBurnsCheck.checked
    property alias cfg_KenBurnsSpeed: kenBurnsSpeedSpin.value
    property alias cfg_ShowAttribution: attributionCheck.checked
    property alias cfg_AttributionCorner: attributionCornerCombo.currentValue
    property alias cfg_AttributionAutoHideSec: attributionHideSpin.value
    property alias cfg_AttributionFontScale: attributionScaleSpin.value
    property alias cfg_RequestTimeoutSec: requestTimeoutSpin.value
    property alias cfg_RetryDelaySec: retryDelaySpin.value
    property alias cfg_RetryAttempts: retryAttemptsSpin.value
    property alias cfg_NotifyOnRefresh: notifyRefreshCheck.checked
    property alias cfg_NotifyOnError: notifyErrorCheck.checked
    property alias cfg_ShowStatusBanner: statusBannerCheck.checked
    property alias cfg_DiskCacheEnabled: diskCacheCheck.checked
    property alias cfg_DiskCacheMaxSlots: diskCacheSlotsSpin.value
    property alias cfg_OfflineCacheFallback: offlineCacheCheck.checked
    property alias cfg_OfflineOnlyMode: offlineOnlyCheck.checked
    property alias cfg_MeteredCacheOnly: meteredCacheCheck.checked
    property alias cfg_UseKWalletForApiKey: kwalletCheck.checked
    property alias cfg_ControlBusEnabled: controlBusCheck.checked
    property alias cfg_SyncAdvanceEnabled: syncAdvanceCheck.checked
    property alias cfg_SyncAdvanceGroup: syncGroupField.text
    property alias cfg_VarietyMetadataEnabled: varietyCheck.checked
    property alias cfg_TimeOfDayEnabled: timeOfDayCheck.checked
    property alias cfg_DaySearch: daySearchField.text
    property alias cfg_NightSearch: nightSearchField.text
    property alias cfg_ScheduleEnabled: scheduleCheck.checked
    property alias cfg_WeekdaySearch: weekdaySearchField.text
    property alias cfg_WeekendSearch: weekendSearchField.text
    property alias cfg_CollectionRotationEnabled: collectionRotationCheck.checked
    property alias cfg_SyncLockScreen: lockScreenCheck.checked
    property alias cfg_PanelTintEnabled: panelTintCheck.checked
    property alias cfg_ParallaxEnabled: parallaxCheck.checked
    property alias cfg_ParallaxStrength: parallaxStrengthSpin.value
    property alias cfg_VarietyFolderPath: varietyFolderField.text
    property alias cfg_VarietySymlinkEnabled: varietySymlinkCheck.checked

    function tagBlocklistText() {
        if (!wallpaperConfiguration) {
            return "";
        }
        return Wallhaven.parseTagBlocklist(wallpaperConfiguration.TagBlocklistJson || "[]").join(", ");
    }

    function persistTagBlocklist(text) {
        if (!wallpaperConfiguration) {
            return;
        }
        var tags = String(text || "").split(",").map(function(tag) {
            return tag.trim();
        }).filter(function(tag) { return tag.length > 0; });
        wallpaperConfiguration.TagBlocklistJson = Wallhaven.serializeTagBlocklist(tags);
        if (wallpaperConfiguration.writeConfig) {
            wallpaperConfiguration.writeConfig();
        }
    }

    function collectionRotationText() {
        if (!wallpaperConfiguration) {
            return "";
        }
        return Wallhaven.formatCollectionRotationLines(
            Wallhaven.parseCollectionRotation(wallpaperConfiguration.CollectionRotationJson || "[]"),
        );
    }

    function persistCollectionRotation(text) {
        if (!wallpaperConfiguration) {
            return;
        }
        var entries = Wallhaven.parseCollectionRotationLines(text);
        wallpaperConfiguration.CollectionRotationJson = Wallhaven.serializeCollectionRotation(entries);
        if (wallpaperConfiguration.writeConfig) {
            wallpaperConfiguration.writeConfig();
        }
    }

    function refreshHistoryModel() {
        if (!wallpaperConfiguration) {
            historyModel.clear();
            return;
        }
        var entries = Wallhaven.parseWallpaperHistory(wallpaperConfiguration.WallpaperHistoryJson || "[]");
        historyModel.clear();
        for (var i = entries.length - 1; i >= 0; i--) {
            historyModel.append(entries[i]);
        }
    }

    ListModel { id: historyModel }

    function saveConfig() {
        // Keep PreviewImage / attribution keys; they are runtime state for the settings preview.
    }

    function currentPresets() {
        if (!wallpaperConfiguration) {
            return [];
        }
        return Wallhaven.parseSearchPresets(wallpaperConfiguration.SearchPresetsJson || "[]");
    }

    function persistPresets(presets) {
        if (!wallpaperConfiguration) {
            return;
        }
        wallpaperConfiguration.SearchPresetsJson = Wallhaven.serializeSearchPresets(presets);
        if (wallpaperConfiguration.writeConfig) {
            wallpaperConfiguration.writeConfig();
        }
        presetCombo.model = presets;
    }

    function buildCurrentConfigObject() {
        if (!wallpaperConfiguration) {
            return {};
        }
        return {
            SearchText: wallpaperConfiguration.SearchText,
            Sortings: wallpaperConfiguration.Sortings,
            Order: wallpaperConfiguration.Order,
            TopRange: wallpaperConfiguration.TopRange,
            CategoryGeneral: wallpaperConfiguration.CategoryGeneral,
            CategoryAnime: wallpaperConfiguration.CategoryAnime,
            CategoryPeople: wallpaperConfiguration.CategoryPeople,
            PuritySfw: wallpaperConfiguration.PuritySfw,
            PuritySketchy: wallpaperConfiguration.PuritySketchy,
            PurityNsfw: wallpaperConfiguration.PurityNsfw,
            MinWidth: wallpaperConfiguration.MinWidth,
            MinHeight: wallpaperConfiguration.MinHeight,
            Ratio: wallpaperConfiguration.Ratio,
            ColorFilter: wallpaperConfiguration.ColorFilter,
            ExactResolutions: wallpaperConfiguration.ExactResolutions,
            UseBlacklist: wallpaperConfiguration.UseBlacklist,
            TimeOfDayEnabled: wallpaperConfiguration.TimeOfDayEnabled,
            DaySearch: wallpaperConfiguration.DaySearch,
            NightSearch: wallpaperConfiguration.NightSearch,
        };
    }

    function exportSettingsToClipboard() {
        if (!wallpaperConfiguration) {
            return;
        }
        var json = Wallhaven.exportSettingsSnapshot(wallpaperConfiguration);
        settingsClipboardHelper.text = json;
        settingsClipboardHelper.selectAll();
        settingsClipboardHelper.copy();
        importExportStatus.text = i18n("Settings copied to clipboard as JSON.");
    }

    function importSettingsFromText(raw) {
        if (!wallpaperConfiguration) {
            return;
        }
        try {
            var settings = Wallhaven.importSettingsSnapshot(raw);
            var keys = Object.keys(settings);
            for (var i = 0; i < keys.length; i++) {
                wallpaperConfiguration[keys[i]] = settings[keys[i]];
            }
            if (wallpaperConfiguration.writeConfig) {
                wallpaperConfiguration.writeConfig();
            }
            if (liveWallpaper && liveWallpaper.reloadWallpaper) {
                liveWallpaper.reloadWallpaper();
            }
            importExportStatus.text = i18n("Settings imported.");
        } catch (e) {
            importExportStatus.text = i18n("Could not import settings file.");
        }
    }

    spacing: Kirigami.Units.smallSpacing

    QtControls2.TextEdit {
        id: settingsClipboardHelper
        visible: false
        width: 1
        height: 1
    }

    QtControls2.Label {
        id: importExportStatus
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        opacity: 0.7
        visible: text !== ""
    }

    // Current wallpaper: landscape preview above description, centered
    ColumnLayout {
        id: previewColumn
        Layout.fillWidth: true
        Layout.alignment: Qt.AlignHCenter
        Layout.topMargin: Kirigami.Units.smallSpacing
        Layout.bottomMargin: Kirigami.Units.smallSpacing
        Layout.maximumWidth: Math.min(root.previewWidth + Kirigami.Units.largeSpacing * 2, root.width)
        spacing: Kirigami.Units.smallSpacing

        Kirigami.Heading {
            text: i18n("Current Wallpaper")
            level: 3
            Layout.alignment: Qt.AlignHCenter
        }

        Rectangle {
            id: previewFrame
            Layout.preferredWidth: root.previewWidth
            Layout.preferredHeight: root.previewHeight
            Layout.alignment: Qt.AlignHCenter
            color: Kirigami.Theme.backgroundColor
            border.color: Kirigami.Theme.disabledTextColor
            border.width: 1
            radius: Kirigami.Units.smallSpacing
            clip: true

            // Prefer Wallhaven thumb; cache is a screen-grab fallback.
            Image {
                id: thumbPreviewImage
                anchors.fill: parent
                anchors.margins: 1
                fillMode: Image.PreserveAspectCrop
                source: root.previewThumbUrl
                asynchronous: true
                cache: false
                visible: status === Image.Ready
            }

            Image {
                id: filePreviewImage
                anchors.fill: parent
                anchors.margins: 1
                fillMode: Image.PreserveAspectCrop
                source: root.previewFileUrl
                asynchronous: true
                cache: false
                visible: !thumbPreviewImage.visible && status === Image.Ready
            }

            Kirigami.Icon {
                anchors.centerIn: parent
                width: Kirigami.Units.iconSizes.large
                height: width
                source: (root.previewFileUrl || root.previewThumbUrl)
                    ? "image-loading"
                    : "image-x-generic"
                visible: !thumbPreviewImage.visible && !filePreviewImage.visible
            }
        }

        QtControls2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: root.previewWidth
            Layout.alignment: Qt.AlignHCenter
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: root.previewAttribution !== ""
                ? root.previewAttribution
                : i18n("No wallpaper loaded yet. Apply Wallhaven as the wallpaper type and wait for the first image.")
            opacity: root.previewAttribution !== "" ? 1 : 0.7
        }

        QtControls2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: root.previewWidth
            Layout.alignment: Qt.AlignHCenter
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            font.pointSize: Kirigami.Theme.smallFont.pointSize
            opacity: 0.85
            visible: root.previewWallpaperDetails !== ""
            text: root.previewWallpaperDetails
        }

        QtControls2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: root.previewWidth
            Layout.alignment: Qt.AlignHCenter
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            font.pointSize: Kirigami.Theme.smallFont.pointSize
            opacity: 0.7
            text: i18n("Wallpaper Actions: Reload / Next / Similar / Pause / Copy / Block / Save.")
        }
    }

    QtObject {
        id: apiKeyValidator
        property bool checking: false
        property string statusText: ""

        function validate() {
            statusText = "";
            if (!apiKeyField.text) {
                statusText = i18n("Enter an API key first.");
                return;
            }
            checking = true;
            var xhr = new XMLHttpRequest();
            xhr.open("GET", Wallhaven.buildSettingsUrl(apiKeyField.text));
            xhr.timeout = 15000;
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== XMLHttpRequest.DONE) {
                    return;
                }
                checking = false;
                if (xhr.status === 200) {
                    statusText = i18n("API key is valid.");
                    if (wallpaperConfiguration) {
                        wallpaperConfiguration.ApiKeyValid = true;
                    }
                } else {
                    statusText = i18n("API key validation failed (%1).", xhr.status);
                    if (wallpaperConfiguration) {
                        wallpaperConfiguration.ApiKeyValid = false;
                    }
                }
            };
            xhr.onerror = function() {
                checking = false;
                statusText = i18n("Network error while validating API key.");
            };
            xhr.send();
        }
    }

    QtObject {
        id: searchValidator
        property bool checking: false
        property string statusText: ""

        function testSearch() {
            statusText = "";
            checking = true;
            var cfg = root.buildCurrentConfigObject();
            cfg.FileTypeFilter = fileTypeCombo.currentValue;
            cfg.ApiKey = apiKeyField.text;
            cfg.Sortings = sortingsCombo.currentValue;
            cfg.Order = orderCombo.currentValue;
            cfg.TopRange = topRangeCombo.currentValue;
            var state = {
                page: 1,
                seed: "test",
                searchQuery: searchTextField.text,
                screenWidth: 1920,
                screenHeight: 1080,
            };
            var xhr = new XMLHttpRequest();
            xhr.open("GET", Wallhaven.buildSearchUrl(cfg, state));
            xhr.timeout = 20000;
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== XMLHttpRequest.DONE) {
                    return;
                }
                checking = false;
                if (xhr.status !== 200) {
                    statusText = i18n("Search test failed (%1).", xhr.status);
                    return;
                }
                try {
                    var json = JSON.parse(xhr.responseText);
                    var total = json.meta && json.meta.total !== undefined ? json.meta.total : 0;
                    statusText = i18n("Search test: %1 result(s).", total);
                } catch (e) {
                    statusText = i18n("Could not parse search response.");
                }
            };
            xhr.onerror = function() {
                checking = false;
                statusText = i18n("Network error during search test.");
            };
            xhr.send();
        }
    }

    QtObject {
        id: collectionsLoader
        property var entries: []
        property bool loading: false
        property string errorText: ""

        function refresh() {
            errorText = "";
            if (!apiKeyField.text) {
                errorText = i18n("Enter an API key first.");
                return;
            }
            loading = true;
            entries = [];
            var xhr = new XMLHttpRequest();
            xhr.open("GET", Wallhaven.buildCollectionsUrl(apiKeyField.text));
            xhr.setRequestHeader("Accept", "application/json");
            xhr.timeout = 30000;
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== XMLHttpRequest.DONE) {
                    return;
                }
                loading = false;
                if (xhr.status === 200) {
                    try {
                        entries = Wallhaven.parseCollectionsResponse(JSON.parse(xhr.responseText));
                        if (!entries.length) {
                            errorText = i18n("No collections found for this API key.");
                        } else {
                            syncPickerSelection();
                        }
                    } catch (e) {
                        errorText = i18n("Could not parse collections response.");
                    }
                } else {
                    errorText = i18n("Failed to load collections (%1).", xhr.status);
                }
            };
            xhr.onerror = function() {
                loading = false;
                errorText = i18n("Network error while loading collections.");
            };
            xhr.ontimeout = function() {
                loading = false;
                errorText = i18n("Timed out while loading collections.");
            };
            xhr.send();
        }

        function applySelection(index) {
            if (index < 0 || index >= entries.length) {
                return;
            }
            var entry = entries[index];
            collectionUserField.text = entry.username;
            collectionIdField.text = entry.id;
        }

        function syncPickerSelection() {
            for (var i = 0; i < entries.length; i++) {
                if (entries[i].id === collectionIdField.text
                        && entries[i].username === collectionUserField.text) {
                    collectionPickerCombo.currentIndex = i;
                    return;
                }
            }
        }
    }

    Item {
        Layout.fillWidth: true
        Layout.preferredHeight: tabBar.implicitHeight

        QtControls2.TabBar {
            id: tabBar
            anchors.horizontalCenter: parent.horizontalCenter
            width: implicitWidth

            QtControls2.TabButton { text: i18n("Source") }
            QtControls2.TabButton { text: i18n("Filters") }
            QtControls2.TabButton { text: i18n("Playback") }
            QtControls2.TabButton { text: i18n("Advanced") }
        }
    }

    StackLayout {
        id: tabs
        Layout.fillWidth: true
        Layout.fillHeight: true
        currentIndex: tabBar.currentIndex

        // Source
        QtControls2.ScrollView {
            id: sourceScroll
            contentWidth: availableWidth
            clip: true

            Kirigami.FormLayout {
                id: sourceForm
                width: sourceScroll.availableWidth
                twinFormLayouts: typeof appearanceRoot !== "undefined" ? [appearanceRoot.parentLayout] : []

                QtControls2.ComboBox {
                    id: browseModeCombo
                    Kirigami.FormData.label: i18n("Browse mode:")
                    textRole: "label"
                    valueRole: "value"
                    model: [
                        { label: i18n("Search"), value: "search" },
                        { label: i18n("Collection"), value: "collection" },
                        { label: i18n("Favorites"), value: "favorites" },
                    ]
                }

                QtControls2.TextField {
                    id: searchTextField
                    Kirigami.FormData.label: i18n("Search string:")
                    placeholderText: i18n("Tags, keywords, e.g. nature anime")
                    visible: browseModeCombo.currentValue === "search"
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Test search:")
                    text: searchValidator.checking ? i18n("Testing…") : i18n("Test search")
                    visible: browseModeCombo.currentValue === "search"
                    enabled: !searchValidator.checking
                    onClicked: searchValidator.testSearch()
                }

                QtControls2.Label {
                    Kirigami.FormData.label: " "
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    visible: browseModeCombo.currentValue === "search" && searchValidator.statusText !== ""
                    text: searchValidator.statusText
                }

                QtControls2.TextField {
                    id: apiKeyField
                    Kirigami.FormData.label: i18n("API key:")
                    placeholderText: i18n("Optional; required for NSFW and favorites")
                    echoMode: TextInput.Password
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Validate key:")
                    text: apiKeyValidator.checking ? i18n("Checking…") : i18n("Test API key")
                    enabled: apiKeyField.text !== "" && !apiKeyValidator.checking
                    onClicked: apiKeyValidator.validate()
                }

                QtControls2.Label {
                    Kirigami.FormData.label: " "
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    visible: apiKeyValidator.statusText !== ""
                    text: apiKeyValidator.statusText
                }

                QtControls2.CheckBox {
                    id: kwalletCheck
                    Kirigami.FormData.label: i18n("KWallet:")
                    text: i18n("Load API key from KWallet on startup")
                }

                QtControls2.TextField {
                    id: collectionUserField
                    Kirigami.FormData.label: i18n("Collection user:")
                    placeholderText: i18n("Username for collection/favorites override")
                    visible: browseModeCombo.currentValue !== "search"
                }

                QtControls2.TextField {
                    id: collectionIdField
                    Kirigami.FormData.label: i18n("Collection ID:")
                    visible: browseModeCombo.currentValue === "collection"
                }

                QtControls2.Button {
                    id: loadCollectionsButton
                    Kirigami.FormData.label: i18n("Collections:")
                    text: collectionsLoader.loading ? i18n("Loading…") : i18n("Load collections")
                    visible: browseModeCombo.currentValue === "collection"
                    enabled: apiKeyField.text !== "" && !collectionsLoader.loading
                    onClicked: collectionsLoader.refresh()
                }

                QtControls2.ComboBox {
                    id: collectionPickerCombo
                    Kirigami.FormData.label: i18n("Pick collection:")
                    textRole: "display"
                    visible: browseModeCombo.currentValue === "collection"
                        && collectionsLoader.entries.length > 0
                    model: collectionsLoader.entries
                    onActivated: collectionsLoader.applySelection(currentIndex)
                }

                QtControls2.Label {
                    Kirigami.FormData.label: " "
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    visible: browseModeCombo.currentValue === "collection"
                        && collectionsLoader.errorText !== ""
                    text: collectionsLoader.errorText
                }

                QtControls2.CheckBox {
                    id: collectionRotationCheck
                    Kirigami.FormData.label: i18n("Rotate collections:")
                    text: i18n("Cycle through multiple collections on each advance")
                    visible: browseModeCombo.currentValue === "collection"
                }

                QtControls2.TextArea {
                    id: collectionRotationField
                    Kirigami.FormData.label: i18n("Collection list:")
                    placeholderText: i18n("username/id per line (optional # label)")
                    visible: browseModeCombo.currentValue === "collection"
                    enabled: collectionRotationCheck.checked
                    text: root.collectionRotationText()
                    onEditingFinished: root.persistCollectionRotation(text)
                }

                QtControls2.ComboBox {
                    id: sortingsCombo
                    Kirigami.FormData.label: i18n("API sorting:")
                    textRole: "label"
                    valueRole: "value"
                    visible: browseModeCombo.currentValue === "search"
                    model: [
                        { label: i18n("Random"), value: "random" },
                        { label: i18n("Date added"), value: "date_added" },
                        { label: i18n("Relevance"), value: "relevance" },
                        { label: i18n("Views"), value: "views" },
                        { label: i18n("Favorites"), value: "favorites" },
                        { label: i18n("Toplist"), value: "toplist" },
                    ]
                }

                QtControls2.ComboBox {
                    id: topRangeCombo
                    Kirigami.FormData.label: i18n("Toplist range:")
                    textRole: "label"
                    valueRole: "value"
                    visible: browseModeCombo.currentValue === "search" && sortingsCombo.currentValue === "toplist"
                    model: [
                        { label: "1d", value: "1d" },
                        { label: "1w", value: "1w" },
                        { label: "1M", value: "1M" },
                        { label: "3M", value: "3M" },
                        { label: "1y", value: "1y" },
                    ]
                }

                QtControls2.ComboBox {
                    id: orderCombo
                    Kirigami.FormData.label: i18n("API order:")
                    textRole: "label"
                    valueRole: "value"
                    visible: browseModeCombo.currentValue === "search"
                    model: [
                        { label: i18n("Descending"), value: "desc" },
                        { label: i18n("Ascending"), value: "asc" },
                    ]
                }

                QtControls2.ComboBox {
                    id: localSortingsCombo
                    Kirigami.FormData.label: i18n("Local sorting:")
                    textRole: "label"
                    valueRole: "value"
                    model: [
                        { label: i18n("Ascending"), value: "ascending" },
                        { label: i18n("Descending"), value: "descending" },
                        { label: i18n("Random"), value: "random" },
                    ]
                }
            }
        }

        // Filters
        QtControls2.ScrollView {
            id: filtersScroll
            contentWidth: availableWidth
            clip: true

            Kirigami.FormLayout {
                width: filtersScroll.availableWidth

                readonly property bool searchFilters: browseModeCombo.currentValue === "search"

                Kirigami.InlineMessage {
                    Layout.fillWidth: true
                    visible: !parent.searchFilters
                    type: Kirigami.MessageType.Information
                    text: i18n("Category, purity, ratio, color, blacklist, and time-of-day filters apply to Search mode only. Collection and Favorites use the collection API as-is.")
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Categories")
                    Kirigami.FormData.isSection: true
                    visible: parent.searchFilters
                }

                QtControls2.CheckBox { id: generalCheck; Kirigami.FormData.label: i18n("General:"); text: i18n("Enabled"); visible: parent.searchFilters }
                QtControls2.CheckBox { id: animeCheck; Kirigami.FormData.label: i18n("Anime:"); text: i18n("Enabled"); visible: parent.searchFilters }
                QtControls2.CheckBox { id: peopleCheck; Kirigami.FormData.label: i18n("People:"); text: i18n("Enabled"); visible: parent.searchFilters }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Purity")
                    Kirigami.FormData.isSection: true
                    visible: parent.searchFilters
                }

                QtControls2.CheckBox { id: sfwCheck; Kirigami.FormData.label: i18n("SFW:"); text: i18n("Enabled"); visible: parent.searchFilters }
                QtControls2.CheckBox { id: sketchyCheck; Kirigami.FormData.label: i18n("Sketchy:"); text: i18n("Enabled"); visible: parent.searchFilters }
                QtControls2.CheckBox { id: nsfwCheck; Kirigami.FormData.label: i18n("NSFW:"); text: i18n("Enabled"); visible: parent.searchFilters }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Resolution & Ratio")
                    Kirigami.FormData.isSection: true
                    visible: parent.searchFilters
                }

                QtControls2.TextField {
                    id: minWidthField
                    Kirigami.FormData.label: i18n("Min width:")
                    placeholderText: i18n("Empty = screen width")
                    visible: parent.searchFilters
                }

                QtControls2.TextField {
                    id: minHeightField
                    Kirigami.FormData.label: i18n("Min height:")
                    placeholderText: i18n("Empty = screen height")
                    visible: parent.searchFilters
                }

                QtControls2.TextField {
                    id: resolutionsField
                    Kirigami.FormData.label: i18n("Exact resolutions:")
                    placeholderText: i18n("e.g. 1920x1080,2560x1440")
                    visible: parent.searchFilters
                }

                QtControls2.ComboBox {
                    id: ratioCombo
                    Kirigami.FormData.label: i18n("Ratio:")
                    textRole: "label"
                    valueRole: "value"
                    visible: parent.searchFilters
                    model: [
                        { label: i18n("All wide"), value: "landscape" },
                        { label: "16×9", value: "16x9" },
                        { label: "21×9", value: "21x9" },
                        { label: "32×9", value: "32x9" },
                        { label: i18n("All portrait"), value: "portrait" },
                        { label: "9×16", value: "9x16" },
                    ]
                }

                QtControls2.ComboBox {
                    id: fileTypeCombo
                    Kirigami.FormData.label: i18n("File type:")
                    textRole: "label"
                    valueRole: "value"
                    visible: parent.searchFilters
                    model: [
                        { label: i18n("Any"), value: "" },
                        { label: "JPEG", value: "jpg" },
                        { label: "PNG", value: "png" },
                    ]
                }

                QtControls2.ComboBox {
                    id: colorCombo
                    Kirigami.FormData.label: i18n("Color:")
                    textRole: "label"
                    valueRole: "value"
                    visible: parent.searchFilters
                    model: [
                        { label: i18n("Any"), value: "" },
                        { label: i18n("System color scheme"), value: "system" },
                        { label: i18n("Red"), value: "660000" },
                        { label: i18n("Dark Red"), value: "990000" },
                        { label: i18n("Bright Red"), value: "cc0000" },
                        { label: i18n("Pink Red"), value: "cc3333" },
                        { label: i18n("Pink"), value: "ea4c88" },
                        { label: i18n("Purple"), value: "993399" },
                        { label: i18n("Dark Purple"), value: "663399" },
                        { label: i18n("Blue Purple"), value: "333399" },
                        { label: i18n("Blue"), value: "0066cc" },
                        { label: i18n("Cyan Blue"), value: "0099cc" },
                        { label: i18n("Teal"), value: "66cccc" },
                        { label: i18n("Green"), value: "77cc33" },
                        { label: i18n("Dark Green"), value: "669900" },
                        { label: i18n("Forest"), value: "336600" },
                        { label: i18n("Olive"), value: "666600" },
                        { label: i18n("Yellow Green"), value: "999900" },
                        { label: i18n("Yellow"), value: "cccc33" },
                        { label: i18n("Bright Yellow"), value: "ffff00" },
                        { label: i18n("Gold"), value: "ffcc33" },
                        { label: i18n("Orange"), value: "ff9900" },
                        { label: i18n("Dark Orange"), value: "ff6600" },
                        { label: i18n("Brown"), value: "cc6633" },
                        { label: i18n("Tan"), value: "996633" },
                        { label: i18n("Dark Brown"), value: "663300" },
                        { label: i18n("Black"), value: "000000" },
                        { label: i18n("Gray"), value: "999999" },
                        { label: i18n("Light Gray"), value: "cccccc" },
                        { label: i18n("White"), value: "ffffff" },
                        { label: i18n("Slate"), value: "424153" },
                    ]
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Other")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.CheckBox {
                    id: blacklistCheck
                    Kirigami.FormData.label: i18n("Account blacklist:")
                    text: i18n("Apply Wallhaven tag blacklist (Search + API key)")
                    visible: parent.searchFilters
                }

                QtControls2.CheckBox {
                    id: dedupCheck
                    Kirigami.FormData.label: i18n("Duplicates:")
                    text: i18n("Avoid recent duplicates (saved across restarts)")
                }

                QtControls2.TextField {
                    id: tagBlocklistField
                    Kirigami.FormData.label: i18n("Tag blocklist:")
                    placeholderText: i18n("Comma-separated tags to exclude, e.g. nsfw, text")
                    visible: parent.searchFilters
                    text: root.tagBlocklistText()
                    onEditingFinished: root.persistTagBlocklist(text)
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Search Presets")
                    Kirigami.FormData.isSection: true
                    visible: parent.searchFilters
                }

                QtControls2.TextField {
                    id: presetNameField
                    Kirigami.FormData.label: i18n("Preset name:")
                    placeholderText: i18n("e.g. Anime night")
                    visible: parent.searchFilters
                }

                QtControls2.ComboBox {
                    id: presetCombo
                    Kirigami.FormData.label: i18n("Saved presets:")
                    textRole: "name"
                    visible: parent.searchFilters
                    model: root.currentPresets()
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Save preset:")
                    text: i18n("Save current search")
                    visible: parent.searchFilters
                    onClicked: {
                        var name = presetNameField.text.trim();
                        if (!name) {
                            return;
                        }
                        var presets = root.currentPresets().slice();
                        var preset = Wallhaven.buildPresetFromConfig(name, root.buildCurrentConfigObject());
                        var replaced = false;
                        for (var i = 0; i < presets.length; i++) {
                            if (presets[i].name === name) {
                                presets[i] = preset;
                                replaced = true;
                                break;
                            }
                        }
                        if (!replaced) {
                            presets.push(preset);
                        }
                        root.persistPresets(presets);
                        var idx = -1;
                        for (var j = 0; j < presets.length; j++) {
                            if (presets[j].name === name) {
                                idx = j;
                                break;
                            }
                        }
                        presetCombo.currentIndex = idx;
                    }
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Apply preset:")
                    text: i18n("Apply selected preset")
                    visible: parent.searchFilters
                    enabled: presetCombo.currentIndex >= 0
                    onClicked: {
                        var presets = root.currentPresets();
                        var preset = presets[presetCombo.currentIndex];
                        if (preset && wallpaperConfiguration) {
                            Wallhaven.applyPresetToConfig(preset, wallpaperConfiguration);
                            if (wallpaperConfiguration.writeConfig) {
                                wallpaperConfiguration.writeConfig();
                            }
                        }
                    }
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Delete preset:")
                    text: i18n("Delete selected preset")
                    visible: parent.searchFilters
                    enabled: presetCombo.currentIndex >= 0
                    onClicked: {
                        var presets = root.currentPresets().slice();
                        presets.splice(presetCombo.currentIndex, 1);
                        root.persistPresets(presets);
                        presetCombo.currentIndex = -1;
                    }
                }
            }
        }

        // Playback & effects
        QtControls2.ScrollView {
            id: playbackScroll
            contentWidth: availableWidth
            clip: true

            Kirigami.FormLayout {
                width: playbackScroll.availableWidth

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Slideshow")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.SpinBox {
                    id: intervalSpin
                    Kirigami.FormData.label: i18n("Interval (min):")
                    from: 0
                    to: 10080
                }

                QtControls2.CheckBox {
                    id: slideshowPausedCheck
                    Kirigami.FormData.label: i18n("Pause:")
                    text: i18n("Pause automatic slideshow")
                    enabled: intervalSpin.value > 0
                }

                QtControls2.Label {
                    Kirigami.FormData.label: " "
                    text: i18n("0 = manual only. Pause also available from desktop Wallpaper Actions.")
                    opacity: 0.7
                    wrapMode: Text.WordWrap
                }

                QtControls2.SpinBox {
                    id: jitterSpin
                    Kirigami.FormData.label: i18n("Interval jitter (%):")
                    from: 0
                    to: 50
                }

                QtControls2.SpinBox {
                    id: dayIntervalSpin
                    Kirigami.FormData.label: i18n("Day interval (min):")
                    from: 0
                    to: 10080
                }

                QtControls2.SpinBox {
                    id: nightIntervalSpin
                    Kirigami.FormData.label: i18n("Night interval (min):")
                    from: 0
                    to: 10080
                }

                QtControls2.Label {
                    Kirigami.FormData.label: " "
                    text: i18n("Day/night intervals override the base interval when set (6am–8pm = day).")
                    opacity: 0.7
                    wrapMode: Text.WordWrap
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Effects")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.ComboBox {
                    id: qualityCombo
                    Kirigami.FormData.label: i18n("Image quality:")
                    textRole: "label"
                    valueRole: "value"
                    model: [
                        { label: i18n("Small (thumbnail, low bandwidth)"), value: "small" },
                        { label: i18n("Large (full wallpaper)"), value: "large" },
                        { label: i18n("Original (full wallpaper)"), value: "original" },
                    ]
                }

                QtControls2.SpinBox {
                    id: crossfadeSpin
                    Kirigami.FormData.label: i18n("Crossfade (ms):")
                    from: 0
                    to: 3000
                    stepSize: 100
                }

                QtControls2.ComboBox {
                    id: transitionCombo
                    Kirigami.FormData.label: i18n("Transition:")
                    textRole: "label"
                    valueRole: "value"
                    model: [
                        { label: i18n("Crossfade"), value: "crossfade" },
                        { label: i18n("Fade through black"), value: "fadeblack" },
                        { label: i18n("Slide"), value: "slide" },
                        { label: i18n("Zoom"), value: "zoom" },
                        { label: i18n("Random"), value: "random" },
                        { label: i18n("Instant"), value: "instant" },
                    ]
                }

                QtControls2.CheckBox {
                    id: parallaxCheck
                    Kirigami.FormData.label: i18n("Parallax:")
                    text: i18n("Subtle per-screen wallpaper offset")
                }

                QtControls2.SpinBox {
                    id: parallaxStrengthSpin
                    Kirigami.FormData.label: i18n("Parallax strength:")
                    from: 0
                    to: 100
                    enabled: parallaxCheck.checked
                }

                QtControls2.CheckBox {
                    id: lockScreenCheck
                    Kirigami.FormData.label: i18n("Lock screen:")
                    text: i18n("Sync lock screen wallpaper when cached")
                }

                QtControls2.CheckBox {
                    id: panelTintCheck
                    Kirigami.FormData.label: i18n("Panel tint hint:")
                    text: i18n("Write dominant color JSON for external theming tools")
                }

                QtControls2.CheckBox {
                    id: kenBurnsCheck
                    Kirigami.FormData.label: i18n("Ken Burns:")
                    text: i18n("Slow pan/zoom")
                }

                QtControls2.SpinBox {
                    id: kenBurnsSpeedSpin
                    Kirigami.FormData.label: i18n("Ken Burns speed:")
                    from: 1
                    to: 100
                    enabled: kenBurnsCheck.checked
                }

                QtControls2.CheckBox {
                    id: attributionCheck
                    Kirigami.FormData.label: i18n("Attribution:")
                    text: i18n("Show overlay on desktop")
                }

                QtControls2.ComboBox {
                    id: attributionCornerCombo
                    Kirigami.FormData.label: i18n("Attribution corner:")
                    textRole: "label"
                    valueRole: "value"
                    enabled: attributionCheck.checked
                    model: [
                        { label: i18n("Bottom left"), value: "bottom-left" },
                        { label: i18n("Bottom right"), value: "bottom-right" },
                        { label: i18n("Top left"), value: "top-left" },
                        { label: i18n("Top right"), value: "top-right" },
                    ]
                }

                QtControls2.SpinBox {
                    id: attributionHideSpin
                    Kirigami.FormData.label: i18n("Auto-hide (sec):")
                    from: 0
                    to: 120
                    enabled: attributionCheck.checked
                }

                QtControls2.SpinBox {
                    id: attributionScaleSpin
                    Kirigami.FormData.label: i18n("Font scale (%):")
                    from: 70
                    to: 150
                    enabled: attributionCheck.checked
                }
            }
        }

        // Advanced
        QtControls2.ScrollView {
            id: advancedScroll
            contentWidth: availableWidth
            clip: true

            Kirigami.FormLayout {
                width: advancedScroll.availableWidth

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Network & Retries")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.SpinBox {
                    id: requestTimeoutSpin
                    Kirigami.FormData.label: i18n("Request timeout (sec):")
                    from: 5
                    to: 120
                }

                QtControls2.SpinBox {
                    id: retryDelaySpin
                    Kirigami.FormData.label: i18n("Retry delay (sec):")
                    from: 1
                    to: 300
                }

                QtControls2.SpinBox {
                    id: retryAttemptsSpin
                    Kirigami.FormData.label: i18n("Max retry attempts:")
                    from: 1
                    to: 20
                }

                QtControls2.Label {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: i18n("Timeout is per request. Retries use the delay with exponential backoff, up to the max attempts.")
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Notifications")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.CheckBox {
                    id: notifyRefreshCheck
                    Kirigami.FormData.label: i18n("On refresh:")
                    text: i18n("System notification when wallpaper changes")
                }

                QtControls2.CheckBox {
                    id: notifyErrorCheck
                    Kirigami.FormData.label: i18n("On errors:")
                    text: i18n("System notification for errors and warnings")
                }

                QtControls2.CheckBox {
                    id: statusBannerCheck
                    Kirigami.FormData.label: i18n("Desktop banner:")
                    text: i18n("Show status messages on the wallpaper")
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Performance")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.CheckBox {
                    id: diskCacheCheck
                    Kirigami.FormData.label: i18n("Disk cache:")
                    text: i18n("Cache recent wallpapers locally (faster revisits)")
                }

                QtControls2.SpinBox {
                    id: diskCacheSlotsSpin
                    Kirigami.FormData.label: i18n("Cache slots:")
                    from: 5
                    to: 200
                    enabled: diskCacheCheck.checked
                }

                QtControls2.CheckBox {
                    id: offlineCacheCheck
                    Kirigami.FormData.label: i18n("Offline fallback:")
                    text: i18n("Show cached wallpapers when the network fails")
                    enabled: diskCacheCheck.checked
                }

                QtControls2.CheckBox {
                    id: offlineOnlyCheck
                    Kirigami.FormData.label: i18n("Offline only:")
                    text: i18n("Never use the network; cycle cached wallpapers only")
                    enabled: diskCacheCheck.checked
                }

                QtControls2.CheckBox {
                    id: meteredCacheCheck
                    Kirigami.FormData.label: i18n("Metered network:")
                    text: i18n("Use cache only on cellular connections")
                    enabled: diskCacheCheck.checked
                }

                QtControls2.CheckBox {
                    id: varietyCheck
                    Kirigami.FormData.label: i18n("Variety metadata:")
                    text: i18n("Write current wallpaper JSON for external tools")
                }

                QtControls2.TextField {
                    id: varietyFolderField
                    Kirigami.FormData.label: i18n("Variety folder:")
                    placeholderText: i18n("Optional path for Variety integration")
                }

                QtControls2.CheckBox {
                    id: varietySymlinkCheck
                    Kirigami.FormData.label: i18n("Variety symlink:")
                    text: i18n("Symlink cached wallpaper as wallhaven-current.jpg")
                    enabled: varietyFolderField.text !== ""
                }

                QtControls2.Label {
                    Kirigami.FormData.label: i18n("Cache status:")
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: liveWallpaper
                        ? i18n("%1 cached wallpaper(s)", liveWallpaper.diskCacheEntryCount)
                        : i18n("Apply Wallhaven as the wallpaper type to see cache stats.")
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Clear cache:")
                    text: i18n("Clear disk cache")
                    enabled: liveWallpaper !== null && diskCacheCheck.checked
                    onClicked: {
                        if (liveWallpaper && liveWallpaper.clearDiskCache) {
                            liveWallpaper.clearDiskCache();
                        }
                    }
                }

                QtControls2.Label {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: i18n("Images decode to screen size. Inactive crossfade layers are released, and settings preview writes are deferred.")
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Blocklist")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.Label {
                    Kirigami.FormData.label: i18n("Blocked IDs:")
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: wallpaperConfiguration
                        ? i18n("%1 blocked wallpaper(s)", Wallhaven.parseBlockedIds(wallpaperConfiguration.BlockedIdsJson || "[]").length)
                        : i18n("Apply Wallhaven as the wallpaper type to manage the blocklist.")
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Clear blocklist:")
                    text: i18n("Clear blocklist")
                    enabled: liveWallpaper !== null
                    onClicked: {
                        if (liveWallpaper && liveWallpaper.clearBlockedIds) {
                            liveWallpaper.clearBlockedIds();
                        }
                    }
                }

                QtControls2.Label {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: i18n("Block the current wallpaper from desktop Wallpaper Actions. Blocked IDs are skipped during search.")
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("External Control")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.CheckBox {
                    id: controlBusCheck
                    Kirigami.FormData.label: i18n("Control bus:")
                    text: i18n("Accept commands from plasmoid/CLI")
                }

                QtControls2.CheckBox {
                    id: syncAdvanceCheck
                    Kirigami.FormData.label: i18n("Sync advance:")
                    text: i18n("Advance all monitors in the same group together")
                }

                QtControls2.TextField {
                    id: syncGroupField
                    Kirigami.FormData.label: i18n("Sync group:")
                    placeholderText: i18n("default")
                    enabled: syncAdvanceCheck.checked
                }

                QtControls2.Label {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: i18n("Per-monitor profiles: set a different sync group and search on each screen, or the same group to advance together.")
                }

                QtControls2.Label {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: i18n("Use tools/wallhaven-ctl.sh, D-Bus (tools/wallhaven-dbus.py), or the Wallhaven Control plasmoid.")
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Wallpaper History")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Refresh history:")
                    text: i18n("Refresh history gallery")
                    onClicked: root.refreshHistoryModel()
                }

                GridView {
                    id: historyGrid
                    Kirigami.FormData.label: i18n("Recent:")
                    Layout.preferredWidth: parent.width
                    Layout.preferredHeight: Math.min(220, Math.ceil(count / 4) * 72)
                    cellWidth: 96
                    cellHeight: 72
                    clip: true
                    model: historyModel
                    delegate: Item {
                        width: historyGrid.cellWidth
                        height: historyGrid.cellHeight
                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                if (liveWallpaper && liveWallpaper.showHistoryWallpaper) {
                                    liveWallpaper.showHistoryWallpaper(model.id);
                                }
                            }
                        }
                        Image {
                            anchors.centerIn: parent
                            width: 88
                            height: 56
                            fillMode: Image.PreserveAspectCrop
                            asynchronous: true
                            source: model.thumbUrl
                        }
                    }
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Clear history:")
                    text: i18n("Clear wallpaper history")
                    enabled: liveWallpaper !== null
                    onClicked: {
                        if (liveWallpaper && liveWallpaper.clearWallpaperHistory) {
                            liveWallpaper.clearWallpaperHistory();
                            root.refreshHistoryModel();
                        }
                    }
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Settings Backup")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Export:")
                    text: i18n("Copy settings to clipboard")
                    onClicked: root.exportSettingsToClipboard()
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Export file:")
                    text: i18n("Save settings to file…")
                    enabled: liveWallpaper !== null
                    onClicked: exportSettingsDialog.open()
                }

                QtControls2.Button {
                    Kirigami.FormData.label: i18n("Import:")
                    text: i18n("Import settings from file…")
                    onClicked: importSettingsDialog.open()
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Time of Day")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.Label {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: i18n("Time-of-day searches apply in Search mode only (6am–8pm day, otherwise night).")
                }

                QtControls2.CheckBox {
                    id: timeOfDayCheck
                    Kirigami.FormData.label: i18n("Time of day:")
                    text: i18n("Use separate day/night searches")
                }

                QtControls2.TextField {
                    id: daySearchField
                    Kirigami.FormData.label: i18n("Day search:")
                    placeholderText: i18n("6am–8pm")
                    enabled: timeOfDayCheck.checked
                }

                QtControls2.TextField {
                    id: nightSearchField
                    Kirigami.FormData.label: i18n("Night search:")
                    placeholderText: i18n("8pm–6am")
                    enabled: timeOfDayCheck.checked
                }

                Kirigami.Separator {
                    Kirigami.FormData.label: i18n("Weekday Schedule")
                    Kirigami.FormData.isSection: true
                }

                QtControls2.Label {
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    opacity: 0.7
                    text: i18n("Weekday/weekend searches apply in Search mode when time-of-day is disabled.")
                }

                QtControls2.CheckBox {
                    id: scheduleCheck
                    Kirigami.FormData.label: i18n("Week schedule:")
                    text: i18n("Use separate weekday/weekend searches")
                    enabled: !timeOfDayCheck.checked
                }

                QtControls2.TextField {
                    id: weekdaySearchField
                    Kirigami.FormData.label: i18n("Weekday search:")
                    placeholderText: i18n("Mon–Fri")
                    enabled: scheduleCheck.checked && !timeOfDayCheck.checked
                }

                QtControls2.TextField {
                    id: weekendSearchField
                    Kirigami.FormData.label: i18n("Weekend search:")
                    placeholderText: i18n("Sat–Sun")
                    enabled: scheduleCheck.checked && !timeOfDayCheck.checked
                }
            }
        }
    }

    FileDialog {
        id: importSettingsDialog
        title: i18n("Import Wallhaven Settings")
        nameFilters: [i18n("JSON files (*.json)")]
        fileMode: FileDialog.OpenFile
        onAccepted: settingsImportLoader.load(selectedFile)
    }

    FileDialog {
        id: exportSettingsDialog
        title: i18n("Export Wallhaven Settings")
        nameFilters: [i18n("JSON files (*.json)")]
        fileMode: FileDialog.SaveFile
        defaultSuffix: "json"
        onAccepted: {
            if (liveWallpaper && liveWallpaper.exportSettingsToFile) {
                liveWallpaper.exportSettingsToFile(selectedFile);
                importExportStatus.text = i18n("Settings exported to file.");
            }
        }
    }

    QtObject {
        id: settingsImportLoader
        function load(fileUrl) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", fileUrl);
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== XMLHttpRequest.DONE) {
                    return;
                }
                if (xhr.status === 0 || xhr.status === 200) {
                    root.importSettingsFromText(xhr.responseText);
                } else {
                    importExportStatus.text = i18n("Could not read settings file.");
                }
            };
            xhr.send();
        }
    }

    Connections {
        target: wallpaperConfiguration
        enabled: wallpaperConfiguration !== null
        function onWallpaperHistoryJsonChanged() { root.refreshHistoryModel(); }
        function onPreviewImageChanged() {
            filePreviewImage.source = "";
            filePreviewImage.source = root.previewFileUrl;
        }
        function onPreviewThumbUrlChanged() {
            thumbPreviewImage.source = "";
            thumbPreviewImage.source = root.previewThumbUrl;
        }
        function onPreviewWallpaperIdChanged() {
            thumbPreviewImage.source = "";
            thumbPreviewImage.source = root.previewThumbUrl;
        }
        function onPreviewAttributionChanged() {
            // Aspect may change between portrait/landscape wallpapers.
            thumbPreviewImage.source = "";
            thumbPreviewImage.source = root.previewThumbUrl;
        }
    }

    Component.onCompleted: refreshHistoryModel()
}
